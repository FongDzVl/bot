var ls4 = function ls4(type, data) {
    var args = data.args;
    var prefix = global.config.commandPrefix;
    args.shift();
    if(args[0]) {
        if(args[0] == "1") {
            if(args[1] == "14") {
                return {
                    handler: "internal",
                    data: "Câu 1 trang 14 Lịch Sử lớp 4:\nNước Văn Lang ra đời vào thời gian nào và ở khu vực nào trên đất nước ta?\nTrả lời:\n- Nước Văn Lang đời khoảng năm 700 trước công nguyên (TCN).\n- Ở khu vực Bắc Bộ và Bắc Trung Bộ hiện nay."
                }
            } else if (args[1] == "17") {
                return {
                    handler: "internal",
                    data: ""
                }
            } else if (args[1] == "18") {
                return {
                    handler: "internal",
                    data: ""
                }
            } else if (args[1] == "21") {
                return {
                    handler: "internal",
                    data: ""
                }
            } else if (args[1] == "22") {
                return {
                    handler: "internal",
                    data: ""
                }
            } else if (args[1] == "24") {
                return {
                    handler: "internal",
                    data: ""
                }
            } else if (args[1] == "27") {
                return {
                    handler: "internal",
                    data: ""
                }
            } else if (args[1] == "28") {
                return {
                    handler: "internal",
                    data: ""
                }
            } else if (args[1] == "29") {
                return {
                    handler: "internal",
                    data: ""
                }
            } else if (args[1] == "32") {
                return {
                    handler: "internal",
                    data: ""
                }
            } else if (args[1] == "34") {
                return {
                    handler: "internal",
                    data: ""
                }
            } else if (args[1] == "36") {
                return {
                    handler: "internal",
                    data: ""
                }
            } else if (args[1] == "38") {
                return {
                    handler: "internal",
                    data: ""
                }
            } else if (args[1] == "40") {
                return {
                    handler: "internal",
                    data: ""
                }
            } else if (args[1] == "42") {
                return {
                    handler: "internal",
                    data: ""
                }
            } else if (args[1] == "44") {
                return {
                    handler: "internal",
                    data: ""
                }
            } else if (args[1] == "46") {
                return {
                    handler: "internal",
                    data: ""
                }
            } else if (args[1] == "48") {
                return {
                    handler: "internal",
                    data: ""
                }
            } else if (args[1] == "50") {
                return {
                    handler: "internal",
                    data: ""
                }
            } else if (args[1] == "52") {
                return {
                    handler: "internal",
                    data: ""
                }
            } else if (args[1] == "53") {
                return {
                    handler: "internal",
                    data: ""
                }
            } else if (args[1] == "55") {
                return {
                    handler: "internal",
                    data: ""
                }
            } else if (args[1] == "56") {
                return {
                    handler: "internal",
                    data: ""
                }
            } else if (args[1] == "58") {
                return {
                    handler: "internal",
                    data: ""
                }
            } else if (args[1] == "60") {
                return {
                    handler: "internal",
                    data: ""
                }
            } else if (args[1] == "63") {
                return {
                    handler: "internal",
                    data: ""
                }
            } else if (args[1] == "64") {
                return {
                    handler: "internal",
                    data: ""
                }
            } else if (args[1] == "66") {
                return {
                    handler: "internal",
                    data: ""
                }
            } else if (args[1] == "68") {
                return {
                    handler: "internal",
                    data: ""
                }
            } else {
                return {
                    handler: 'internal',
                    response: 'Không tìm thấy trang này'
                }
            }
        } else if (args[0] == "2") {
            if(args[1] == "14") {
                return {
                    handler: "internal",
                    data: ""
                }
            } else if (args[1] == "17") {
                return {
                    handler: "internal",
                    data: ""
                }
            } else if (args[1] == "18") {
                return {
                    handler: "internal",
                    data: ""
                }
            } else if (args[1] == "21") {
                return {
                    handler: "internal",
                    data: ""
                }
            } else if (args[1] == "22") {
                return {
                    handler: "internal",
                    data: ""
                }
            } else if (args[1] == "24") {
                return {
                    handler: "internal",
                    data: ""
                }
            } else if (args[1] == "27") {
                return {
                    handler: "internal",
                    data: ""
                }
            } else if (args[1] == "28") {
                return {
                    handler: "internal",
                    data: ""
                }
            } else if (args[1] == "29") {
                return {
                    handler: "internal",
                    data: ""
                }
            } else if (args[1] == "32") {
                return {
                    handler: "internal",
                    data: ""
                }
            } else if (args[1] == "34") {
                return {
                    handler: "internal",
                    data: ""
                }
            } else if (args[1] == "36") {
                return {
                    handler: "internal",
                    data: ""
                }
            } else if (args[1] == "38") {
                return {
                    handler: "internal",
                    data: ""
                }
            } else if (args[1] == "40") {
                return {
                    handler: "internal",
                    data: ""
                }
            } else if (args[1] == "42") {
                return {
                    handler: "internal",
                    data: ""
                }
            } else if (args[1] == "44") {
                return {
                    handler: "internal",
                    data: ""
                }
            } else if (args[1] == "46") {
                return {
                    handler: "internal",
                    data: ""
                }
            } else if (args[1] == "48") {
                return {
                    handler: "internal",
                    data: ""
                }
            } else if (args[1] == "50") {
                return {
                    handler: "internal",
                    data: ""
                }
            } else if (args[1] == "52") {
                return {
                    handler: "internal",
                    data: ""
                }
            } else if (args[1] == "53") {
                return {
                    handler: "internal",
                    data: ""
                }
            } else if (args[1] == "55") {
                return {
                    handler: "internal",
                    data: ""
                }
            } else if (args[1] == "56") {
                return {
                    handler: "internal",
                    data: ""
                }
            } else if (args[1] == "58") {
                return {
                    handler: "internal",
                    data: ""
                }
            } else if (args[1] == "60") {
                return {
                    handler: "internal",
                    data: ""
                }
            } else if (args[1] == "63") {
                return {
                    handler: "internal",
                    data: ""
                }
            } else if (args[1] == "64") {
                return {
                    handler: "internal",
                    data: ""
                }
            } else if (args[1] == "66") {
                return {
                    handler: "internal",
                    data: ""
                }
            } else if (args[1] == "68") {
                return {
                    handler: "internal",
                    data: ""
                }
            } else {
                return {
                    handler: 'internal',
                    response: 'Không tìm thấy trang này'
                }
            }
        } else if (args[0] == "3") {
            if(args[1] == "14") {
                return {
                    handler: "internal",
                    data: ""
                }
            } else if (args[1] == "18") {
                return {
                    handler: "internal",
                    data: ""
                }
            } else if (args[1] == "24") {
                return {
                    handler: "internal",
                    data: ""
                }
            } else if (args[1] == "27") {
                return {
                    handler: "internal",
                    data: ""
                }
            } else if (args[1] == "29") {
                return {
                    handler: "internal",
                    data: ""
                }
            } else if (args[1] == "42") {
                return {
                    handler: "internal",
                    data: ""
                }
            } else if (args[1] == "46") {
                return {
                    handler: "internal",
                    data: ""
                }
            } else if (args[1] == "52") {
                return {
                    handler: "internal",
                    data: ""
                }
            } else if (args[1] == "53") {
                return {
                    handler: "internal",
                    data: ""
                }
            } else if (args[1] == "60") {
                return {
                    handler: "internal",
                    data: ""
                }
            } else {
                return {
                    handler: 'internal',
                    response: 'Không tìm thấy trang này'
                }
            }
        } else {
            return {
                handler: 'internal',
                response: 'Không tìm thấy bài này'
            }
        }
    } else return {
        handler: 'internal',
        data: `\`${prefix}ls4 {câu} {trang}\`\n"Các câu trả lời có thể bị lỗi do quá dài hoặc căn chỉnh không đúng, lưu ý khi sử dụng!"`
    }
}
module.exports = {
	ls4: ls4
}